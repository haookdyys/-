package com.xuexiang.xupdate.easy;

import android.content.Context;
import com.xuexiang.xupdate.proxy.impl.DefaultUpdateChecker;

public class EasyUpdate {
    private DefaultUpdateChecker checker;
    public static EasyUpdate create(Context context, String url) { return new EasyUpdate(); }
    public EasyUpdate updateChecker(DefaultUpdateChecker checker) { this.checker = checker; return this; }
    public void update() {
        if (checker != null) {
            checker.onBeforeCheck();
            checker.noNewVersion(null);
        }
    }
}
