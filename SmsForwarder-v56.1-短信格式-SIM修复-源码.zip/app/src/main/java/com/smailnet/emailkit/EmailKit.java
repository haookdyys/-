package com.smailnet.emailkit;

import android.content.Context;

public class EmailKit {
    public static void initialize(Context context) { }
    public static void destroy() { }

    public interface GetSendCallback {
        void onSuccess();
        void onFailure(String errMsg);
    }

    public static class Config {
        public String host;
        public int port;
        public boolean ssl;
        public String account;
        public String password;

        public Config setSMTP(String host, int port, boolean ssl) { this.host = host; this.port = port; this.ssl = ssl; return this; }
        public Config setAccount(String account) { this.account = account; return this; }
        public Config setPassword(String password) { this.password = password; return this; }
    }

    public static SMTPService useSMTPService(Config config) { return new SMTPService(config); }

    public static class SMTPService {
        private final Config config;
        public SMTPService(Config config) { this.config = config; }
        public void send(Draft draft, GetSendCallback callback) {
            if (callback != null) callback.onFailure("当前定制版未集成邮件发送组件");
        }
    }
}
