package com.idormy.sms.forwarder.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.provider.Telephony;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.idormy.sms.forwarder.R;

public class KeepAliveUtils {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean isIgnoreBatteryOptimization(Activity activity) {
        PowerManager powerManager = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            return powerManager.isIgnoringBatteryOptimizations(activity.getPackageName());
        } else {
            return true;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void ignoreBatteryOptimization(Activity activity) {
        if (isIgnoreBatteryOptimization(activity)) {
            openAppBatterySetting(activity);
            return;
        }
        @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + activity.getPackageName()));
        ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo != null) {
            activity.startActivity(intent);
        } else {
            openAppBatterySetting(activity);
        }
    }

    /**
     * 打开手机系统电池/后台电量相关页面。
     * v4：把“省电模式/节电助手”放到最后，优先走设置里的电池首页。
     */
    public static void openAppBatterySetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        String pkg = activity.getPackageName();

        // v15：先尝试进入“当前应用”的电池/耗电行为控制页面。
        // OPPO 上第一层“允许后台运行”弹窗不等于真正打开“允许完全后台行为”，
        // 所以要优先把用户带到当前应用耗电行为控制页。
        Intent[] oppoAppBatteryControl = new Intent[]{
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerControlActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.athena", "com.oplus.athena.powersave.PowerSaveActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerControlActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageDetailActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("pkg", pkg)
        };

        Intent[] commonBatteryHome = new Intent[]{
                new Intent("android.settings.BATTERY_SETTINGS"),
                new Intent("android.intent.action.POWER_USAGE_SUMMARY"),
                new Intent("android.settings.POWER_USAGE_SUMMARY"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BatteryDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$PowerUsageSummaryActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.fuelgauge.PowerUsageSummary"))
        };

        // OPPO / OnePlus / Realme：已测试能进入电池首页，保留靠前。
        Intent[] oppoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerControlActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.power.PowerUsageSummaryActivity"))
        };

        // vivo / iQOO：v16 不再打开手机管家首页，也不再优先工程/底层电池页。
        // 目标：先尝试当前应用后台高耗电/电池管理页；失败就直接去 vivo 设置电池首页/搜索电池。
        Intent[] vivoBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.vivo.settings", "com.vivo.settings.Settings$BatterySettingsActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.settings", "com.vivo.settings.battery.BatterySettingsActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.settings", "com.vivo.settings.Settings$PowerUsageSummaryActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BatteryDashboardActivity")),
                new Intent("android.settings.BATTERY_SETTINGS"),
                new Intent("android.intent.action.POWER_USAGE_SUMMARY")
        };

        Intent[] vivoBatterySearch = new Intent[]{
                new Intent("android.settings.SEARCH_SETTINGS")
                        .putExtra("query", "电池")
                        .putExtra("android.intent.extra.TEXT", "电池"),
                new Intent("com.android.settings.action.SETTINGS_SEARCH")
                        .putExtra("query", "电池")
                        .putExtra("android.intent.extra.TEXT", "电池"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra("query", "电池")
                        .putExtra("android.intent.extra.TEXT", "电池"),
                new Intent(Settings.ACTION_SETTINGS)
        };

        Intent[] xiaomiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.PowerMainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.powercenter", "com.miui.powercenter.MainActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.powercenter.BatteryHistoryDetailActivity"))
        };

        Intent[] huaweiBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.PowerUsageActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.BatteryHistoryActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.PowerManagerActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"))
        };

        Intent[] samsungBattery = new Intent[]{
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.battery.ui.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        };

        if (manufacturer.contains("oppo") || manufacturer.contains("oneplus") || manufacturer.contains("realme") || manufacturer.contains("oplus")) {
            // v21：OPPO 优先尝试进入当前应用的耗电/后台行为控制页，方便手动开启“完全允许后台行为”。
            // 如果系统不允许直达，再进入 OPPO 电池首页；最后才进入通用电池页。
            if (startFirstAvailable(activity, oppoAppBatteryControl, false)) return;
            if (startFirstAvailable(activity, oppoBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            // vivo 电池页多次实测不稳定：不再跳工程电池页/手机管家页，直接进系统设置首页。
            startFirstAvailable(activity, new Intent[]{new Intent(Settings.ACTION_SETTINGS)}, false);
            return;
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            if (startFirstAvailable(activity, xiaomiBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            if (startFirstAvailable(activity, huaweiBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        } else if (manufacturer.contains("samsung")) {
            if (startFirstAvailable(activity, samsungBattery, false)) return;
            if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        }

        if (startFirstAvailable(activity, commonBatteryHome, false)) return;
        if (startFirstAvailable(activity, oppoBattery, false)) return;
        if (startFirstAvailable(activity, xiaomiBattery, false)) return;
        if (startFirstAvailable(activity, vivoBattery, false)) return;
        if (startFirstAvailable(activity, huaweiBattery, false)) return;
        if (startFirstAvailable(activity, samsungBattery, false)) return;

        // 最后兜底才进入省电模式/系统设置，避免多数手机误进省电助手。
        Intent[] lastResort = new Intent[]{
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) : null,
                new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, lastResort, true);
    }

    /**
     * 尽量直接打开本应用权限管理页。
     * 厂商权限页不是 Android 统一公开接口，所以这里按常见系统多入口尝试。
     */
    public static void openAppPermissionSetting(Activity activity) {
        String pkg = activity.getPackageName();
        Intent[] intents = new Intent[]{
                new Intent("android.settings.APP_PERMISSION_SETTINGS")
                        .putExtra("android.provider.extra.APP_PACKAGE", pkg)
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
                        .putExtra("packageName", pkg),
                new Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                        .setData(Uri.parse("package:" + pkg))
                        .putExtra("android.intent.extra.SHOW_FRAGMENT", "com.android.settings.applications.AppPermissionSettings"),

                // Xiaomi / MIUI / HyperOS
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg),
                new Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", pkg)
                        .putExtra("extra_package_uid", activity.getApplicationInfo().uid),

                // OPPO / OnePlus / ColorOS / OPlus
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.securitypermission", "com.coloros.securitypermission.permission.PermissionAppPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.PermissionManagerActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.singlepage.PermissionSinglePageActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),
                new Intent().setComponent(new ComponentName("com.oplus.securitypermission", "com.oplus.securitypermission.permission.PermissionAppAllPermissionActivity"))
                        .putExtra("packageName", pkg).putExtra("pkg_name", pkg).putExtra("extra_pkgname", pkg),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.safeguard.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.SoftPermissionDetailActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"))
                        .putExtra("packagename", pkg).putExtra("packageName", pkg),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg).putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.SingleAppActivity"))
                        .putExtra("packageName", pkg),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.permissionmanager.ui.MainActivity"))
                        .putExtra("packageName", pkg),

                // Samsung
                new Intent().setComponent(new ComponentName("com.samsung.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg),
                new Intent().setComponent(new ComponentName("com.google.android.permissioncontroller", "com.android.permissioncontroller.permission.ui.ManagePermissionsActivity"))
                        .putExtra("android.intent.extra.PACKAGE_NAME", pkg)
        };
        startFirstAvailable(activity, intents, false);
    }

    /**
     * 尽量打开厂商自启动设置页。
     * v44：OPPO/ColorOS 改为“自启动页优先，应用总页兜底”。
     * 重点：不再使用 ACTION_APPLICATION_SETTINGS / InstalledAppDetails / ManageApplications，避免跳到“应用管理内部/应用列表”。
     */
    public static void openAutoStartSetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();

        Intent[] vivoAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.SoftwareManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"))
        };

        Intent[] xiaomiAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartDetailManagementActivity"))
        };

        // OPPO 自启动直达候选：只放“自启动/自动启动/启动管理”相关页面。
        // 不放应用详情页、不放应用列表页，避免跳到你截图第一张那种“应用管理内部”。
        Intent[] oppoAutoStartSettings = new Intent[]{
                new Intent("com.oplus.settings.action.AUTO_STARTUP_SETTINGS"),
                new Intent("com.oplus.settings.action.AUTOSTART_SETTINGS"),
                new Intent("com.coloros.settings.action.AUTO_STARTUP_SETTINGS"),
                new Intent("com.coloros.settings.action.AUTOSTART_SETTINGS"),
                new Intent("oppo.intent.action.OPPO_STARTUP_MANAGER"),
                new Intent("oppo.intent.action.OPPO_STARTUP_APP_LIST"),
                new Intent("coloros.intent.action.STARTUP_APP_LIST"),
                new Intent("com.coloros.safecenter.intent.action.STARTUP_APP_LIST"),
                new Intent("com.oplus.safecenter.intent.action.STARTUP_APP_LIST"),

                // ColorOS / Android Settings 里的“设置 -> 应用 -> 自启动”候选
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.AutoStartupSettings")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.StartupAppManageActivity")),

                // OPlus/ColorOS Settings 包名变体
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.android.settings.Settings$AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.android.settings.Settings$AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.android.settings.Settings$StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.Settings$AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.Settings$AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.Settings$StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.autostart.AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.autostart.AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.startup.StartupAppManageActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.android.settings.Settings$AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.android.settings.Settings$AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.android.settings.Settings$StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.autostart.AutoStartSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.autostart.AutoStartupSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.startup.StartupAppListActivity")),

                // 安全中心老版本候选：仍然只放 startup，不放 app manager。
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppManageActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.permission.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.safecenter", "com.oplus.safecenter.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.heytap.safecenter", "com.heytap.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"))
        };

        Intent[] huaweiAutoStart = new Intent[]{
                // 华为/荣耀“应用启动管理”直达候选，尽量不落到普通应用管理页。
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupAppControlActivityNew")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.AutoStartupActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupMgrActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupManagerActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.AppStartupManageActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.bootstart.BootStartActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),

                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupAppControlActivityNew")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.AutoStartupActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupMgrActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupManagerActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.appcontrol.activity.AppStartupManageActivity")),

                // 部分荣耀仍沿用华为类名，但包名换成 hihonor。
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"))
        };

        Intent[] huaweiSettingsAppLaunch = new Intent[]{
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$StartupAppControlSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.AppLaunchSettings")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.applications.AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.android.settings.Settings$AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.android.settings.Settings$StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.huawei.android.settings.Settings$AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.huawei.android.settings.applications.AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.android.settings", "com.android.settings.Settings$AppLaunchSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.android.settings", "com.hihonor.android.settings.Settings$AppLaunchSettingsActivity"))
        };

        Intent[] huaweiSearchAppLaunch = new Intent[]{
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.android.settings")
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.huawei.android.settings")
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.hihonor.android.settings")
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$SearchActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$SearchMainActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.huawei.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理"),
                new Intent().setComponent(new ComponentName("com.hihonor.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "应用启动管理")
                        .putExtra("query", "应用启动管理")
                        .putExtra("android.intent.extra.TEXT", "应用启动管理")
        };

        Intent[] huaweiSearchLaunch = new Intent[]{
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.android.settings")
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.huawei.android.settings")
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent("android.settings.SEARCH_SETTINGS")
                        .setPackage("com.hihonor.android.settings")
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$SearchActivity"))
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$SearchMainActivity"))
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.huawei.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理"),
                new Intent().setComponent(new ComponentName("com.hihonor.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra(SearchManager.QUERY, "启动管理")
                        .putExtra("query", "启动管理")
                        .putExtra("android.intent.extra.TEXT", "启动管理")
        };

        Intent[] huaweiAppServices = new Intent[]{
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$AppAndNotificationDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.settings", "com.android.settings.Settings$AppAndNotificationDashboardActivity"))
        };

        // v51：恢复早期可用的“系统设置搜索页”写法，只搜索“自启动”。
        // 这里不再使用通用 ACTION_SEARCH，避免被百度等第三方 App 接管。
        Intent[] settingsSearchAutoStart = new Intent[]{
                new Intent("android.settings.SEARCH_SETTINGS")
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动"),
                new Intent("com.android.settings.action.SETTINGS_SEARCH")
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动"),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$SearchActivity"))
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动"),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动"),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.android.settings.search.SearchActivity"))
                        .putExtra("query", "自启动")
                        .putExtra("android.intent.extra.TEXT", "自启动")
        };

        // OPPO/ColorOS 正常“设置 -> 应用”总页候选：
        // 目标是你说的那个带“应用管理 / 快应用管理 / 应用分身 / 默认应用 / 自启动 / 关联启动”的页面。
        // 这里故意不放 com.android.settings.Settings$AppDashboardActivity / ACTION_APPLICATION_SETTINGS，
        // 避免跳到新版“最近打开的应用 / 查看所有应用 / 特殊应用权限”那个错误页面。
        Intent[] oppoAppsDashboard = new Intent[]{
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.AppManagerDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.AppManagementDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.AppDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.appmanager.AppManagerActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.application.AppManagerDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.application.AppManagementDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.application.AppDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.settings", "com.oplus.settings.feature.application.ApplicationDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.AppManagerDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.AppManagementDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.AppDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.oplus.settings.feature.appmanager.AppManagerActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.coloros.settings.feature.appmanager.AppManagerDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.coloros.settings.feature.appmanager.AppManagementDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.settings", "com.coloros.settings.feature.appmanager.AppDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.oplus.settings.feature.appmanager.AppManagerDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.oplus.settings.feature.appmanager.AppManagementDashboardActivity")),
                new Intent().setComponent(new ComponentName("com.android.settings", "com.oplus.settings.feature.appmanager.AppDashboardActivity"))
        };

        Intent[] otherAutoStart = new Intent[]{
                new Intent().setComponent(new ComponentName("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity")),
                new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
                new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).putExtra("mobilemanager://function/entry/AutoStart", true),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity"))
        };

        if (manufacturer.contains("vivo") || manufacturer.contains("iqoo")) {
            if (startFirstAvailable(activity, vivoAutoStart, false)) return;
        } else if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            if (startFirstAvailable(activity, xiaomiAutoStart, false)) return;
        } else if (manufacturer.contains("oppo") || manufacturer.contains("oneplus") || manufacturer.contains("realme") || manufacturer.contains("oplus")) {
            // v51：OPPO 只跳系统设置搜索页，搜索“自启动”。
            // 不跳百度、不跳应用管理、不跳应用总页。
            if (startFirstAvailable(activity, settingsSearchAutoStart, false)) return;
            startFirstAvailable(activity, new Intent[]{new Intent(Settings.ACTION_SETTINGS)}, false);
            return;
        } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
            // 华为/荣耀：先弹教程后，优先尝试进入设置搜索页搜索“应用启动管理”。
            // 不跳普通“应用和服务/应用管理”页；搜索不可用时再尝试直达应用启动管理，最后才设置首页。
            if (startFirstAvailable(activity, huaweiSearchAppLaunch, false)) return;
            if (startFirstAvailable(activity, huaweiSearchLaunch, false)) return;
            if (startFirstAvailable(activity, huaweiAutoStart, false)) return;
            if (startFirstAvailable(activity, huaweiSettingsAppLaunch, false)) return;
            startFirstAvailable(activity, new Intent[]{new Intent(Settings.ACTION_SETTINGS)}, false);
            return;
        }

        if (startFirstAvailable(activity, xiaomiAutoStart, false)) return;
        if (startFirstAvailable(activity, vivoAutoStart, false)) return;
        if (startFirstAvailable(activity, otherAutoStart, false)) return;
        if (startFirstAvailable(activity, settingsSearchAutoStart, false)) return;

        startFirstAvailable(activity, new Intent[]{new Intent(Settings.ACTION_SETTINGS)}, false);
    }

    /**
     * 桌面布局锁定/桌面设置入口：优先尝试各品牌桌面设置，失败后进入设置搜索。
     */
    public static void openLauncherLayoutSetting(Activity activity) {
        Intent[] launcherSettings = new Intent[]{
                new Intent().setComponent(new ComponentName("com.miui.home", "com.miui.home.settings.MiuiHomeSettings")),
                new Intent().setComponent(new ComponentName("com.miui.home", "com.miui.home.launcher.LauncherSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.bbk.launcher2", "com.bbk.launcher2.LauncherSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.vivo.launcher", "com.vivo.launcher.settings.LauncherSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.launcher", "com.oppo.launcher.settings.LauncherSettingActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.launcher", "com.coloros.launcher.settings.LauncherSettingActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.android.launcher", "com.huawei.android.launcher.drawer.DrawerSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.android.launcher", "com.huawei.android.launcher.drawer.DrawerSettingsActivity"))
        };
        if (startFirstAvailable(activity, launcherSettings, false)) return;

        Intent[] search = new Intent[]{
                new Intent("android.settings.SEARCH_SETTINGS")
                        .putExtra("query", "锁定桌面布局")
                        .putExtra("android.intent.extra.TEXT", "锁定桌面布局"),
                new Intent("android.settings.SEARCH_SETTINGS")
                        .putExtra("query", "桌面设置")
                        .putExtra("android.intent.extra.TEXT", "桌面设置"),
                new Intent("com.android.settings.action.SETTINGS_SEARCH")
                        .putExtra("query", "锁定桌面布局")
                        .putExtra("android.intent.extra.TEXT", "锁定桌面布局"),
                new Intent(Settings.ACTION_HOME_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };
        startFirstAvailable(activity, search, false);
    }

    /**
     * 短信按钮：优先打开短信 App 设置页；打不开设置页就打开短信/信息 App 主界面；仍打不开就不处理。
     * v4 重点补 OPPO / 小米 / 华为 / 荣耀：加入 ACTION_VIEW sms: 和更多包名/Activity。
     */
    public static void openVivoSmsSettingWithBackStack(Activity activity) {
        Intent[] vivoMain = new Intent[]{
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.bbk.mms"),
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.vivo.mms")
        };

        Intent[] vivoSettings = new Intent[]{
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.bbk.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MessageSettings"))
        };

        boolean openedMain = startFirstAvailable(activity, vivoMain, false);
        if (openedMain) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (!startFirstAvailable(activity, vivoSettings, false)) {
                    openSmsSetting(activity);
                }
            }, 450);
        } else {
            if (!startFirstAvailable(activity, vivoSettings, false)) {
                openSmsSetting(activity);
            }
        }
    }

    public static void openSmsSetting(Activity activity) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        // 小米/Redmi/Poco 按你的要求：短信按钮不处理，点击无反应。
        if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            return;
        }

        // vivo 已验证可以进入信息设置，放前面保留成功逻辑。
        Intent[] settingIntents = new Intent[]{
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.bbk.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MessageSettings")),

                // 通用 / 小米 / MIUI / HyperOS
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.xiaomi.mms", "com.android.mms.ui.MessageSettings")),

                // OPPO / OPlus / Realme / OnePlus
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.coloros.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.oplus.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.heytap.mms.ui.MessageSettings")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.huawei.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MessageSettings")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.huawei.mms.ui.MessageSettings")),

                // Google / Samsung
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.SettingsActivity")),
                new Intent().setComponent(new ComponentName("com.google.android.apps.messaging", "com.google.android.apps.messaging.ui.appsettings.ApplicationSettingsActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.android.mms.ui.MessagingPreferenceActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.messaging", "com.samsung.android.messaging.ui.view.setting.SettingsActivity"))
        };
        if (startFirstAvailable(activity, settingIntents, false)) return;

        // 打不开设置页，优先打开系统默认短信 App。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String defaultSmsPkg = Telephony.Sms.getDefaultSmsPackage(activity);
            if (startPackageLaunch(activity, defaultSmsPkg)) return;
            if (defaultSmsPkg != null && startFirstAvailable(activity, new Intent[]{
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(defaultSmsPkg),
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING).setPackage(defaultSmsPkg)
            }, false)) return;
        }

        // 这个通常能打开默认短信/信息 App，成功率比具体组件更高。
        Intent[] genericSmsIntents = new Intent[]{
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
                new Intent(Intent.ACTION_VIEW).setData(Uri.parse("sms:")),
                new Intent(Intent.ACTION_VIEW).setData(Uri.parse("smsto:")),
                new Intent(Intent.ACTION_SENDTO).setData(Uri.parse("smsto:"))
        };
        if (startFirstAvailable(activity, genericSmsIntents, false)) return;

        Intent[] mainIntents = new Intent[]{
                // 通用 / 小米
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.android.mms", "com.android.mms.ui.ComposeMessageActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.miui.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.xiaomi.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.android.messaging", "com.android.messaging.ui.conversationlist.ConversationListActivity")),

                // OPPO / OPlus / Realme / OnePlus
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.oplus.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.heytap.mms", "com.android.mms.ui.ConversationList")),

                // vivo / iQOO
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.bbk.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.vivo.mms", "com.android.mms.ui.MmsTabActivity")),

                // Huawei / Honor
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.mms", "com.android.mms.ui.ConversationList")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.MmsTabActivity")),
                new Intent().setComponent(new ComponentName("com.hihonor.mms", "com.android.mms.ui.ConversationList")),

                // Google / Samsung
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.apps.messaging"),
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.samsung.android.messaging")
        };
        if (startFirstAvailable(activity, mainIntents, false)) return;

        String[] packages = new String[]{
                "com.bbk.mms",
                "com.vivo.mms",
                "com.android.mms",
                "com.miui.mms",
                "com.xiaomi.mms",
                "com.android.messaging",
                "com.google.android.apps.messaging",
                "com.coloros.mms",
                "com.oplus.mms",
                "com.heytap.mms",
                "com.huawei.mms",
                "com.hihonor.mms",
                "com.android.contacts",
                "com.samsung.android.messaging"
        };
        for (String pkg : packages) {
            if (startPackageLaunch(activity, pkg)) return;
        }
    }

    private static boolean startPackageLaunch(Activity activity, String pkg) {
        if (pkg == null || pkg.trim().length() == 0) return false;
        try {
            PackageManager pm = activity.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(pkg);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(launchIntent);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }


    public static boolean openExternalApp(Activity activity, String packageName) {
        try {
            Intent intent = activity.getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static boolean startFirstAvailable(Activity activity, Intent[] intents, boolean showUnsupportedToast) {
        for (Intent intent : intents) {
            if (intent == null) continue;
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                // v5：显式 Component/Package 页面先直接尝试启动。
                // Android 11+ 有包可见性限制，先 resolveActivity 可能误判为不可用，
                // 直接 startActivity 再捕获异常，成功率更高。
                if (intent.getComponent() != null || intent.getPackage() != null) {
                    try {
                        activity.startActivity(intent);
                        return true;
                    } catch (Exception ignored) {
                        // 继续尝试下一个入口
                    }
                } else {
                    ResolveInfo resolveInfo = activity.getPackageManager().resolveActivity(intent, 0);
                    if (resolveInfo != null) {
                        activity.startActivity(intent);
                        return true;
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (showUnsupportedToast) {
            Toast.makeText(activity, R.string.unsupport, Toast.LENGTH_SHORT).show();
        }
        return false;
    }

}
