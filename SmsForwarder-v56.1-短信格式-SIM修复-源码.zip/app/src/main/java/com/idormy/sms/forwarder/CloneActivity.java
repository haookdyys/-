package com.idormy.sms.forwarder;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CloneActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView textView = new TextView(this);
        textView.setText("配置迁移功能已精简，当前版本只保留短信转发、Bark、Webhook和权限跳转功能。");
        textView.setPadding(48, 48, 48, 48);
        setContentView(textView);
    }
}
