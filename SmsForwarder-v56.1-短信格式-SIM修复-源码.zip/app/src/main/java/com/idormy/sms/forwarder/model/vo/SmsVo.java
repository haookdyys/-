package com.idormy.sms.forwarder.model.vo;

import android.annotation.SuppressLint;\nimport android.os.Build;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;

@Data
public class SmsVo implements Serializable {
    String mobile;
    String content;
    Date date;
    String simInfo;

    public SmsVo() {
    }

    public SmsVo(String mobile, String content, Date date, String simInfo) {
        this.mobile = mobile;
        this.content = content;
        this.date = date;
        this.simInfo = simInfo;
    }

    @SuppressLint("SimpleDateFormat")
    public String getSmsVoForSend(String ruleSmsTemplate) {
        String deviceName = getFriendlyDeviceName();
        String androidVersion = "Android " + Build.VERSION.RELEASE + "（API " + Build.VERSION.SDK_INT + "）";
        String systemVersion = getSystemVersion();

        // 优先取转发规则的自定义模板；未启用自定义模板时使用新版默认格式。
        String customSmsTemplate = "{{短信内容}}\\n{{卡槽信息}}\\n设备：" + deviceName
                + "\\n安卓系统：" + androidVersion
                + (systemVersion.isEmpty() ? "" : "\\n系统版本：" + systemVersion)
                + "\\n推送时间：{{接收时间}}";

        if (ruleSmsTemplate != null && !ruleSmsTemplate.trim().isEmpty()) {
            customSmsTemplate = ruleSmsTemplate;
        } else {
            boolean switchSmsTemplate = SettingUtil.getSwitchSmsTemplate();
            String smsTemplate = SettingUtil.getSmsTemplate().trim();
            if (switchSmsTemplate && !smsTemplate.isEmpty()) {
                customSmsTemplate = smsTemplate;
            }
        }

        return customSmsTemplate.replace("{{来源号码}}", mobile)
                .replace("{{APP包名}}", mobile)
                .replace("{{短信内容}}", content)
                .replace("{{通知内容}}", content)
                .replace("{{卡槽信息}}", simInfo)
                .replace("{{接收时间}}", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date))
                .replace("{{设备名称}}", deviceName)
                .trim();
    }

    private static String getFriendlyDeviceName() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String lower = (manufacturer + " " + brand).toLowerCase();
        String name;
        if (lower.contains("huawei")) name = "华为";
        else if (lower.contains("honor")) name = "荣耀";
        else if (lower.contains("xiaomi") || lower.contains("redmi") || lower.contains("poco")) name = "小米";
        else if (lower.contains("oppo") || lower.contains("oplus")) name = "OPPO";
        else if (lower.contains("oneplus")) name = "一加";
        else if (lower.contains("vivo") || lower.contains("bbk")) name = "vivo";
        else if (lower.contains("samsung")) name = "三星";
        else if (lower.contains("meizu")) name = "魅族";
        else if (lower.contains("realme")) name = "realme";
        else if (lower.contains("zte")) name = "中兴";
        else if (lower.contains("lenovo")) name = "联想";
        else if (lower.contains("motorola")) name = "摩托罗拉";
        else if (lower.contains("google")) name = "Google";
        else name = brand.isEmpty() ? manufacturer : brand;

        if (model.isEmpty()) return name;
        return name.isEmpty() ? model : name + " " + model;
    }

    private static String getSystemVersion() {
        String[] keys = new String[] {
                "ro.build.version.harmony",
                "ro.build.version.emui",
                "ro.build.version.opporom",
                "ro.build.version.coloros",
                "ro.vivo.os.version",
                "ro.miui.ui.version.name",
                "ro.build.version.oneui",
                "ro.build.version.magic"
        };
        for (String key : keys) {
            try {
                Class<?> clazz = Class.forName("android.os.SystemProperties");
                java.lang.reflect.Method method = clazz.getMethod("get", String.class, String.class);
                String value = (String) method.invoke(null, key, "");
                if (value != null && !value.trim().isEmpty()) {
                    return value.trim();
                }
            } catch (Exception ignored) {
            }
        }
        return "";
    }

    @NonNull
    @Override
    public String toString() {
        return "SmsVo{" +
                "mobile='" + mobile + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", simInfo=" + simInfo +
                '}';
    }
}
