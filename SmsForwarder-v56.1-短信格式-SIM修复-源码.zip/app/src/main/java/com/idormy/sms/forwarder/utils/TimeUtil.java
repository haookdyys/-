package com.idormy.sms.forwarder.utils;

import android.annotation.SuppressLint;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class TimeUtil {

    //友好时间显示
    public static String friendlyTime(String utcTime) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat utcFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        utcFormater.setTimeZone(TimeZone.getTimeZone("UTC"));//时区定义并进行时间获取
        Date utcDate;
        try {
            utcDate = utcFormater.parse(utcTime);
        } catch (ParseException e) {
            e.printStackTrace();
            return utcTime;
        }

        //获取utcDate距离当前的秒数
        assert utcDate != null;
        int ct = (int) ((System.currentTimeMillis() - utcDate.getTime()) / 1000);

        if (ct == 0) {
            return "刚刚";
        }

        if (ct > 0 && ct < 60) {
            return ct + "秒前";
        }

        if (ct >= 60 && ct < 3600) {
            return Math.max(ct / 60, 1) + "分钟前";
        }
        if (ct >= 3600 && ct < 86400) {
            return ct / 3600 + "小时前";
        }
        if (ct >= 86400 && ct < 2592000) { //86400 * 30
            int day = ct / 86400;
            return day + "天前";
        }
        if (ct >= 2592000 && ct < 31104000) { //86400 * 30
            return ct / 2592000 + "月前";
        }

        return ct / 31104000 + "年前";
    }

    /**
     * 函数功能描述:UTC时间转本地时间格式
     *
     * @param utcTime UTC时间
     * @return 本地时间格式的时间
     */
    public static String utc2Local(String utcTime) {
        String utcTimePatten = "yyyy-MM-dd HH:mm:ss";
        String localTimePatten = "yyyy-MM-dd HH:mm:ss";
        @SuppressLint("SimpleDateFormat") SimpleDateFormat utcFormater = new SimpleDateFormat(utcTimePatten);
        utcFormater.setTimeZone(TimeZone.getTimeZone("UTC"));//时区定义并进行时间获取

        Date utcDate;
        try {
            utcDate = utcFormater.parse(utcTime);
        } catch (ParseException e) {
            e.printStackTrace();
            return utcTime;
        }

        @SuppressLint("SimpleDateFormat") SimpleDateFormat localFormater = new SimpleDateFormat(localTimePatten);
        localFormater.setTimeZone(TimeZone.getDefault());
        assert utcDate != null;
        return localFormater.format(utcDate.getTime());
    }

}
