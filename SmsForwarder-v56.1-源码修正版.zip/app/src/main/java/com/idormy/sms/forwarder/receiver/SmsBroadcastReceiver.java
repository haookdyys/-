package com.idormy.sms.forwarder.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.telephony.SmsMessage;
import android.util.Log;

import com.idormy.sms.forwarder.model.vo.SmsVo;
import com.idormy.sms.forwarder.MyApplication;
import com.idormy.sms.forwarder.sender.SendUtil;
import com.idormy.sms.forwarder.utils.SettingUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.SimUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class SmsBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String receiveAction = intent.getAction();
        String TAG = "SmsBroadcastReceiver";
        Log.d(TAG, "onReceive intent " + receiveAction);
        if ("android.provider.Telephony.SMS_RECEIVED".equals(receiveAction)) {
            try {
                if (!SettingUtil.getSwitchEnableSms()) {
                    return;
                }

                Bundle extras = intent.getExtras();
                Object[] object = (Object[]) Objects.requireNonNull(extras).get("pdus");
                if (object != null) {

                    // 每次收到短信都刷新一次 SIM 信息。
                    // 这样即使 APP 第一次启动时没有手机号权限，用户后来授权后，
                    // 下一条短信到来时也会重新尝试读取 SIM1/SIM2 手机号码。
                    try {
                        List<PhoneUtils.SimInfo> freshSimList = PhoneUtils.getSimMultiInfo();
                        if (freshSimList != null) {
                            MyApplication.SimInfoList = freshSimList;
                        }
                    } catch (Throwable refreshError) {
                        Log.w(TAG, "刷新SIM信息失败：" + refreshError.getMessage());
                    }

                    // 接收手机卡信息
                    String simInfo = "";
                    // 卡槽ID，默认卡槽为1
                    int simId = 1;
                    try {
                        if (extras.containsKey("simId")) {
                            simId = extras.getInt("simId");
                        } else if (extras.containsKey("subscription")) {
                            simId = SimUtil.getSimIdBySubscriptionId(extras.getInt("subscription"));
                        }

                        String number = "";
                        if (MyApplication.SimInfoList != null) {
                            for (PhoneUtils.SimInfo info : MyApplication.SimInfoList) {
                                if (info != null && info.mSimSlotIndex + 1 == simId) {
                                    number = info.mNumber == null ? "" : String.valueOf(info.mNumber).trim();
                                    if (TextUtils.isEmpty(number) || "null".equalsIgnoreCase(number)) {
                                        number = "";
                                    }
                                    // SubscriptionInfo.getNumber() 在部分手机上为空，
                                    // 再按 SubscriptionId 直接向 TelephonyManager 查询一次。
                                    if (TextUtils.isEmpty(number) && info.mSubscriptionId > 0) {
                                        number = PhoneUtils.getPhoneNumberForSubscription(info.mSubscriptionId);
                                    }
                                    break;
                                }
                            }
                        }
                        if (TextUtils.isEmpty(number)) {
                            number = "未读取";
                        }
                        simInfo = "卡" + simId + "：" + number;
                    } catch (Exception e) {
                        Log.e(TAG, "获取接收SIM号码失败：" + e.getMessage());
                        simInfo = "卡" + simId + "：未读取";
                    }

                    List<SmsVo> smsVoList = new ArrayList<>();
                    String format = intent.getStringExtra("format");
                    Map<String, String> mobileToContent = new HashMap<>();
                    Date date = new Date();
                    for (Object pdus : object) {
                        byte[] pdusMsg = (byte[]) pdus;
                        SmsMessage sms = SmsMessage.createFromPdu(pdusMsg, format);
                        String mobile = sms.getOriginatingAddress();//发送短信的手机号
                        if (mobile == null) {
                            continue;
                        }
                        //下面是获取短信的发送时间
                        date = new Date(sms.getTimestampMillis());

                        String content = mobileToContent.get(mobile);
                        if (content == null) content = "";

                        content += sms.getMessageBody();//短信内容
                        mobileToContent.put(mobile, content);

                    }
                    for (String mobile : mobileToContent.keySet()) {
                        smsVoList.add(new SmsVo(mobile, mobileToContent.get(mobile), date, simInfo));
                    }
                    Log.d(TAG, "短信：" + smsVoList);
                    SendUtil.send_msg_list(context, smsVoList, simId, "sms");

                }

            } catch (Throwable throwable) {
                Log.e(TAG, "解析短信失败：" + throwable.getMessage());
            }

        }

    }

}