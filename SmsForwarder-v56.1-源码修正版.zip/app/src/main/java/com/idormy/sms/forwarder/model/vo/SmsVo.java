package com.idormy.sms.forwarder.model.vo;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;

@Data
public class SmsVo implements Serializable {
    String mobile;
    String content;
    Date date;
    String simInfo;

    public SmsVo() {
    }

    public SmsVo(String mobile, String content, Date date, String simInfo) {
        this.mobile = mobile;
        this.content = content;
        this.date = date;
        this.simInfo = simInfo;
    }

    @SuppressLint("SimpleDateFormat")
    public String getSmsVoForSend(String ruleSmsTemplate) {
        String deviceMark = getDeviceDisplay();
        String customSmsTemplate = "{{短信内容}}\n\n{{卡槽信息}}\n{{设备名称}}\n{{安卓系统}}\n{{系统版本}}\n推送时间：{{接收时间}}";

        //优先取转发规则的自定义模板，留空则取全局设置
        if (!ruleSmsTemplate.isEmpty()) {
            customSmsTemplate = ruleSmsTemplate;
        } else {
            boolean switchSmsTemplate = SettingUtil.getSwitchSmsTemplate();
            String smsTemplate = SettingUtil.getSmsTemplate().trim();
            if (switchSmsTemplate && !smsTemplate.isEmpty()) {
                customSmsTemplate = smsTemplate;
            }
        }

        return customSmsTemplate.replace("{{来源号码}}", mobile).replace("{{APP包名}}", mobile)
                .replace("{{短信内容}}", content).replace("{{通知内容}}", content)
                .replace("{{卡槽信息}}", TextUtils.isEmpty(simInfo) ? "卡1：未读取" : simInfo)
                .replace("{{接收时间}}", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date))
                .replace("{{设备名称}}", deviceMark)
                .replace("{{安卓系统}}", getAndroidVersion())
                .replace("{{系统版本}}", getSystemVersion())
                .trim();
    }

    private String getDeviceDisplay() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String lower = (manufacturer + " " + brand).toLowerCase();
        String name;
        if (lower.contains("huawei")) name = "华为";
        else if (lower.contains("honor")) name = "荣耀";
        else if (lower.contains("xiaomi") || lower.contains("redmi") || lower.contains("poco")) name = "小米";
        else if (lower.contains("oppo") || lower.contains("oplus")) name = "OPPO";
        else if (lower.contains("oneplus")) name = "一加";
        else if (lower.contains("realme")) name = "realme";
        else if (lower.contains("vivo") || lower.contains("iqoo")) name = "vivo";
        else if (lower.contains("samsung")) name = "三星";
        else if (lower.contains("motorola") || lower.contains("moto")) name = "摩托罗拉";
        else name = !TextUtils.isEmpty(manufacturer) ? manufacturer : brand;
        return "设备：" + name + (TextUtils.isEmpty(model) ? "" : " " + model);
    }

    private String getAndroidVersion() {
        String release = Build.VERSION.RELEASE == null ? "未知" : Build.VERSION.RELEASE;
        return "Android " + release + "（API " + Build.VERSION.SDK_INT + "）";
    }

    private String getSystemVersion() {
        String[][] props = new String[][] {
                {"华为/鸿蒙", "ro.build.version.harmony"},
                {"荣耀/MagicOS", "ro.build.version.magic"},
                {"OPPO/ColorOS", "ro.build.version.opporom"},
                {"vivo/OriginOS", "ro.vivo.os.version"},
                {"小米/MIUI", "ro.miui.ui.version.name"},
                {"三星/One UI", "ro.build.version.oneui"},
                {"魅族/Flyme", "ro.build.display.id"}
        };
        for (String[] prop : props) {
            String value = readSystemProperty(prop[1]);
            if (!TextUtils.isEmpty(value) && !"unknown".equalsIgnoreCase(value)) {
                return "系统版本：" + prop[0] + " " + value;
            }
        }
        return "系统版本：未读取";
    }

    private String readSystemProperty(String key) {
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method method = clazz.getMethod("get", String.class, String.class);
            return String.valueOf(method.invoke(null, key, ""));
        } catch (Throwable ignored) {
            return "";
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "SmsVo{" +
                "mobile='" + mobile + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", simInfo=" + simInfo +
                '}';
    }
}
